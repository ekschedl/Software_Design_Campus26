package Adapter.PdfDocx;

public  class PdfReader {

    public  void loadPfd(String file){
        System.out.println("Loading PDF file: example.pdf" + file);
    };
}
