package at.campus02.iwi.bsp1;

public class Boots extends Product {

	@Override
	public String getSpeed() {
		return "by foot";
	}
}
