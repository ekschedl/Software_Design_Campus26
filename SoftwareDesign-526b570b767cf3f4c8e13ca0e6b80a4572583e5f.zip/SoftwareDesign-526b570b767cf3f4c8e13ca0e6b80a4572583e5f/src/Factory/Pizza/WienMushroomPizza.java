package Factory.Pizza;

public class WienMushroomPizza extends Pizza {
    public WienMushroomPizza() {
        name = "Wien Mushroom";
    }
}
