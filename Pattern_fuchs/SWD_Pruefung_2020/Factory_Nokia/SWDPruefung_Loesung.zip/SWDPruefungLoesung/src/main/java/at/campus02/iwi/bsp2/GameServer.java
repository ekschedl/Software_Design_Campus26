package at.campus02.iwi.bsp2;

public interface GameServer {
    public void registerObserver(GameClient gc);

    public void removeObserver(GameClient gc);

    public void notifyObservers();
}
