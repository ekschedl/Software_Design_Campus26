package Factory.AutoFabrik;

public enum AutoType {
    PKW, LKW, SUV
}
