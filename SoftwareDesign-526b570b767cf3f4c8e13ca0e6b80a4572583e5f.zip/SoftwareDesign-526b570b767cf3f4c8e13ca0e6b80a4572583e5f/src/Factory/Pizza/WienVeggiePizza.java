package Factory.Pizza;

public class WienVeggiePizza extends Pizza {
    public WienVeggiePizza() {
        name = "Wien Veggie Pizza";
    }
}
