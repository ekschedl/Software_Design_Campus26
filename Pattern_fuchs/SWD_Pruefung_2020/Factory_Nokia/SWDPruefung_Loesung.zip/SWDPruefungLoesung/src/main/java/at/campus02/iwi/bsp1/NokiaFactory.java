package at.campus02.iwi.bsp1;

public abstract class NokiaFactory {

	abstract Product produce(ProductType type);
	

	public Product getProduct(ProductType type) {

		
		Product c = produce(type);

		if ( c == null)
		{
			return null;
		}
		

		c.addSerialNumber();
		
		return c;
	}
	
	
}
