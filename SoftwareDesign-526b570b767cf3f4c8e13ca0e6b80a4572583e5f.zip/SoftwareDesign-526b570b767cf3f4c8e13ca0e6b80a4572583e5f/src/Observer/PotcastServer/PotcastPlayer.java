package Observer.PotcastServer;

public interface PotcastPlayer {

    public void getPotcast(Potcast potcast);

    public String getPotcastPlayerName();
}
