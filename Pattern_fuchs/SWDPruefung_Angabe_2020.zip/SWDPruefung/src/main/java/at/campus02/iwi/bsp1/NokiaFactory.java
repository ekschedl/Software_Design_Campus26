package at.campus02.iwi.bsp1;

public class NokiaFactory {

	// Methodensignatur bitte nicht verändern!!
	public Product getProduct(ProductType type) {

		Product c = null;

		// hier darf programmiert werden


		
		// AB HIER NICHT MEHR VERÄNDERN
		// JEDES Produkt muss eine Seriennummer erhalten
		c.addSerialNumber();
		
		return c;
	}
}
