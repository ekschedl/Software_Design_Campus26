package Strategy.Provision;

public interface ProvisionStrategie {

    public double berechenProvisionEinesMitarbeiters(Mitarbeiter m);

}
