package Command.Fernbedienung;

// Interface für das Kommando
public interface Kommando {
  void ausfuehren();
}
