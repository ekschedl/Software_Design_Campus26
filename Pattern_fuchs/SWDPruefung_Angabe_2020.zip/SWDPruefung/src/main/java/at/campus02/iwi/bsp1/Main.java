package at.campus02.iwi.bsp1;

public class Main {
    // bitte selbst implementieren
}
