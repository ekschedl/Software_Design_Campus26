package at.campus02.iwi.bsp1;

public class BaseStation5G extends Product {

	@Override
	public String getSpeed() {
		return "5G";
	}
}
