package Command.CommandPatternTV;

public class Licht {
    public void an(){
        System.out.println("Licht ist an");
    }
    public void aus(){
        System.out.println("Licht ist aus");
    }
}
