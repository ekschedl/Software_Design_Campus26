package Command.Fernbedienung;

// Licht-Klasse, die die Aktionen "an" und "aus" definiert
public class Licht {
    public void an() {
        System.out.println("Licht ist an");
    }

    public void aus() {
        System.out.println("Licht ist aus");
    }
}
