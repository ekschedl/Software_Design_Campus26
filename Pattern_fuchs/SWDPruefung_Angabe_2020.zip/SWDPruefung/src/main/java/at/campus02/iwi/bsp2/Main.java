package at.campus02.iwi.bsp2;

public class Main {
    // teste mich (falls du zeit hast )
}
