package at.campus02.iwi.bsp1;

public class Product {

	public void addSerialNumber()
	{
		System.out.println("Add serial number " + toString());
	}
	
	@Override
	public String toString() {
		return String.format("%s", this.getClass().getName());
	}

}
