package Observer.FitnessTracker;

public interface Geraete {

    public void erhalte(Fortschritt fortschritt);

    public String getName();
}
