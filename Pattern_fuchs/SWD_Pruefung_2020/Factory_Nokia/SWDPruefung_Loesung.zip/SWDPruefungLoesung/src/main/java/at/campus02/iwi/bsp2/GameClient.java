package at.campus02.iwi.bsp2;

public interface GameClient {
    public void update(EventData evt);

    public void startGame(GameServer server);
    public void endGame();
}
