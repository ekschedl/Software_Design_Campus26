package Adapter.LegacyDataSource;

public interface DataSource {
    public String fetchDataSource(String query);
}
