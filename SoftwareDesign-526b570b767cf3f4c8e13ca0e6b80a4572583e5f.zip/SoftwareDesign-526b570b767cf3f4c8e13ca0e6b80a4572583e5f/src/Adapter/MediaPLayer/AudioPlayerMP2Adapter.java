package Adapter.MediaPLayer;

public class AudioPlayerMP2Adapter implements IPlayer{
    @Override
    public void play(String file) {

    }
}
