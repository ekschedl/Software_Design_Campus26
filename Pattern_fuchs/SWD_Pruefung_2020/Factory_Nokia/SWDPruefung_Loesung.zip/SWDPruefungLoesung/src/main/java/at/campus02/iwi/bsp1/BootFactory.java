package at.campus02.iwi.bsp1;

public class BootFactory extends NokiaFactory {

	@Override
	Product produce(ProductType type) {
		switch(type)
		{
		case BOOTS:
			return new Boots();
		default:
			return null;
		}
	
	}

}
