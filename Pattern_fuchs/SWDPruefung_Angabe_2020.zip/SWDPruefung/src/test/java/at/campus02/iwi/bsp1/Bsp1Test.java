package at.campus02.iwi.bsp1;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

public class Bsp1Test {

    @Test
    public void testFactory() {
//        Product c = new BaseStationFactory().getProduct(ProductType.STATION5G);
//        assertEquals(BaseStation5G.class, c.getClass());
//        assertEquals("5G", c.getSpeed());
//
//
//        c = new BaseStationFactory().getProduct(ProductType.STATION4G);
//        assertEquals(BaseStation4G.class, c.getClass());
//        assertEquals("4G", c.getSpeed());
//        c = new BaseStationFactory().getProduct(ProductType.STATION3G);
//        assertEquals(BaseStation3G.class, c.getClass());
//        assertEquals("3G", c.getSpeed());
//        c = new BaseStationFactory().getProduct(ProductType.BOOTS);
//        assertNull(c);
//
//        c = new BootFactory().getProduct(ProductType.BOOTS);
//        assertEquals(Boots.class, c.getClass());
//        assertEquals("by foot", c.getSpeed());
//        c = new BootFactory().getProduct(ProductType.STATION3G);
//        assertNull(c);
    }

}

