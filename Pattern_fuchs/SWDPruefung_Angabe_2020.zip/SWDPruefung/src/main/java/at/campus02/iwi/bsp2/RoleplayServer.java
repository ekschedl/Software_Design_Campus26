package at.campus02.iwi.bsp2;

import java.util.ArrayList;

public class RoleplayServer {

    ArrayList<GameClient> clients;
    EventData lastEvent;

    public RoleplayServer(){
        lastEvent = null;
        clients = new ArrayList<GameClient>();
    }
    public ArrayList<GameClient> getClients() {
        return clients;
    }
    public EventData getLastEvent() {
        return lastEvent;
    }


    public void newEvent(String description, String url){

    }

}
