package at.campus02.iwi.bsp2;

public class Main {
    // i am lazy test yourself please
}
