package Factory.AutoFabrik;

public class PKW extends AutoTyp{

    public PKW() {
        name= AutoType.PKW;
    }
}
