package Factory.Pizza;

public class GrazMushroomPizza extends Pizza {
    public GrazMushroomPizza() {
        name = "Graz Mushroom";
    }
}
