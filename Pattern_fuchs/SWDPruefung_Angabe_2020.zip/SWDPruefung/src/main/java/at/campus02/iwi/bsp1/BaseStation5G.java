package at.campus02.iwi.bsp1;

public class BaseStation5G {

}
