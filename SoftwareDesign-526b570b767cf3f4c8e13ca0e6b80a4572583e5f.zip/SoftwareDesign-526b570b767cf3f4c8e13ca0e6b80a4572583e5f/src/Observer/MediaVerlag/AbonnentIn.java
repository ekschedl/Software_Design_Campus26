package Observer.MediaVerlag;

public interface AbonnentIn {
    public void update(Article article);
    public String getName();

}
