package Factory.Pizza;

public class GrazVeggiePizza extends Pizza {
    public GrazVeggiePizza() {
        name = "Graz Veggie Pizza";
    }
}
