package Command.Musiksteuerung;

public interface Kommando {
    public void ausfuehren();
}
