package Adapter.MediaPLayer;

public interface IPlayer {

    void play(String file);
}
