package at.campus02.iwi.bsp1;

public class BaseStation4G extends Product {

	@Override
	public String getSpeed() {
		return "4G";
	}
}
