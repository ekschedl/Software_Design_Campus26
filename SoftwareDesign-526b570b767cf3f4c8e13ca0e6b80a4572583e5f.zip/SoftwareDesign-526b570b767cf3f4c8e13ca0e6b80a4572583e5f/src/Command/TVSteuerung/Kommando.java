package Command.TVSteuerung;

public interface Kommando {

public void ausfuehren();


}
