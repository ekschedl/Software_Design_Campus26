package at.campus02.iwi.bsp2;

import at.campus02.iwi.bsp1.*;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;
import static org.junit.Assert.assertFalse;

public class Bsp2Test {


    private AppClient ac19, ac80, ac191, ac801;
    private ConsoleClient ccN, ccM;
    private RoleplayServer rs;

    @Before
    public void setUp() throws Exception {
        ac19 = new AppClient(1000, 19);
        ac80 = new AppClient(1000, 80);
        ac191 = new AppClient(1, 19);
        ac801 = new AppClient(1, 80);

        ccN = new ConsoleClient("Nintendo");
        ccM = new ConsoleClient("Microsoft");

        rs = new RoleplayServer();
    }

    @Test
    public void testUniversal() {
        // test add
//        assertEquals(0, rs.getClients().size());
//        ac19.startGame(rs);
//        ac80.startGame(rs);
//        ac191.startGame(rs);
//        ac801.startGame(rs);
//        ccN.startGame(rs);
//        ccM.startGame(rs);
//        assertEquals(6, rs.getClients().size());
//        assertTrue(rs.getClients().contains(ac19));
//        assertTrue(rs.getClients().contains(ac80));
//        assertTrue(rs.getClients().contains(ac191));
//        assertTrue(rs.getClients().contains(ac801));
//        assertTrue(rs.getClients().contains(ccN));
//        assertTrue(rs.getClients().contains(ccM));
//
//        // test new event
//        rs.newEvent("Gewitter", "https://campus02.at/game/thunder");
//        EventData e = rs.getLastEvent();
//
//        assertNotEquals(ac19.getLastEventURL(), e.getEventDataURL());
//        assertEquals(ccM.getLastEventURL(), e.getEventDataURL());
//        assertEquals(ac80.getLastEventURL(), e.getEventDataURL());
//        assertNotEquals(ac191.getLastEventURL(), e.getEventDataURL());
//        assertNotEquals(ac801.getLastEventURL(), e.getEventDataURL());
//        assertNotEquals(ccN.getLastEventURL(), e.getEventDataURL());
//
//
//        // test remove
//        ac801.endGame();
//        ccM.endGame();
//        assertEquals(4, rs.getClients().size());
//        assertFalse(rs.getClients().contains(ac801));
//        assertFalse(rs.getClients().contains(ccM));

    }

}
