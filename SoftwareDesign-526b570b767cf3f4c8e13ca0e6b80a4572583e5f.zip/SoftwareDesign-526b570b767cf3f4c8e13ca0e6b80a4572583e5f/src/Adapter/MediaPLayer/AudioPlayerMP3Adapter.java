package Adapter.MediaPLayer;

public class AudioPlayerMP3Adapter implements IPlayer{
    @Override
    public void play(String file) {

    }
}
