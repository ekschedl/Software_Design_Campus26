package at.campus02.iwi.bsp1;

public enum ProductType {
	BOOTS, STATION3G, STATION4G, STATION5G
}
