package Command.SmartHomeSteuerung;

public interface CommandInterface {
    public void execute();
}
