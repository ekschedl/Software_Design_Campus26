package at.campus02.iwi.bsp1;

public class Main {
    // i am lazy test yourself please
}
