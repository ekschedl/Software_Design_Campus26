package Factory.Computer;

// DO NOT CHANGE
public enum ComputerType {
    SMARTPHONE, TABLET, SERVER, DESKTOP
}
