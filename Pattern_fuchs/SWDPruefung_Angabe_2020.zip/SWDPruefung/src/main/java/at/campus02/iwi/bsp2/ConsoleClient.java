package at.campus02.iwi.bsp2;

public class ConsoleClient {
    private String system;
    private String lastEventURL;

    public ConsoleClient(String system) {

        this.system = system;
        lastEventURL = null;
    }


    public String getSystem() {
        return system;
    }
    public String getLastEventURL() {
        return lastEventURL;
    }



}
