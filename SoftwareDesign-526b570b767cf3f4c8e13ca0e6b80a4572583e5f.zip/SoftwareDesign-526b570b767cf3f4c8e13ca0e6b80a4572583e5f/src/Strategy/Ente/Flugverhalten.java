package Strategy.Ente;

public interface Flugverhalten {

    public void fliegen();
}
