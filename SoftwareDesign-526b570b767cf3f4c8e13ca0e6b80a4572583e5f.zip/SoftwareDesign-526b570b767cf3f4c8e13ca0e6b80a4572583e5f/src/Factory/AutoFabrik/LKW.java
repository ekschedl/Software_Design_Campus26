package Factory.AutoFabrik;

public class LKW extends AutoTyp{

    public LKW() {
        name= AutoType.LKW;
    }
}
