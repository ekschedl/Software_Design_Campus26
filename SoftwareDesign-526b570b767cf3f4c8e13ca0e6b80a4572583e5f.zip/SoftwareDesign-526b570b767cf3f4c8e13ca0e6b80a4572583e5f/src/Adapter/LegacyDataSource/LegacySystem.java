package Adapter.LegacyDataSource;

public class LegacySystem {

    public String getData(String LegacyQuery){
        return "Fetching LegacyQuery: "+LegacyQuery;
    }
}
