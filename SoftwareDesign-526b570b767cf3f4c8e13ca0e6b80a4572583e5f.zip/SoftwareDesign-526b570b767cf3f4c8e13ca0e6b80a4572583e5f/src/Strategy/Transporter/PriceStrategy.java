package Strategy.Transporter;

public interface PriceStrategy {

    public double berechnePreis(Transporter m, Parcel parcel);

}
