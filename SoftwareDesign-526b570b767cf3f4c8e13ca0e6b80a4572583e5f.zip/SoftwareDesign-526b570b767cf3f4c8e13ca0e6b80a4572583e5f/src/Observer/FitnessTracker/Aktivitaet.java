package Observer.FitnessTracker;

public enum Aktivitaet {
    LAUFEN, RADFAHREN, STEPPEN, AEROBIC
}
