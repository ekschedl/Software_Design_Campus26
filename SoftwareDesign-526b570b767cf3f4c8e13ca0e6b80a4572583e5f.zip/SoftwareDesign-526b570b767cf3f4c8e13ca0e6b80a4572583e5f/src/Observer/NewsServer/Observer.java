package Observer.NewsServer;

public interface Observer {


    public void update(Artikel artikel);
    public String getName();
}
