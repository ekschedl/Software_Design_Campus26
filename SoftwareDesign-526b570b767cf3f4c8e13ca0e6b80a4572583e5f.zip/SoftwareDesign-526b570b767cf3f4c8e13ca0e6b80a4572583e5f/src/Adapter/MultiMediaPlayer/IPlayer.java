package Adapter.MultiMediaPlayer;

public interface IPlayer {
    public void play(String file);
}
