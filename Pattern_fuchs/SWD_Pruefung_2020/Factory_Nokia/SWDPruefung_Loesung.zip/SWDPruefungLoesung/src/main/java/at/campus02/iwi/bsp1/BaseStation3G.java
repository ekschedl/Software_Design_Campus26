package at.campus02.iwi.bsp1;

public class BaseStation3G extends Product {

	@Override
	public String getSpeed() {
		return "3G";
	}
}
