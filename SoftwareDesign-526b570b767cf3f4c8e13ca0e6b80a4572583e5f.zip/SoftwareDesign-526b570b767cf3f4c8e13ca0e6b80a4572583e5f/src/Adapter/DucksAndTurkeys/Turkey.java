package Adapter.DucksAndTurkeys;

public interface Turkey {
    public void gobble();
    public void fly();
}
